from __future__ import annotations
import json, os, pathlib, subprocess, sys, time

ROOT = pathlib.Path(__file__).resolve().parent
EXPECTED = {
    "baseline": "51db4cc3854e6a50395b33f71109a54f0dc84c3a1aae2d89cc8a6448fa12cde1",
    "agenda": "08e146bced1486a21b29dbf5460ea3e33a496a5d5fad8cb7bcd01f70f42ec401",
}

def run_release(name: str) -> None:
    variant = ROOT / "variants" / name
    env = os.environ.copy()
    env["PYTHONPATH"] = str(variant / "src")
    print(f"\n=== {name} release gate ===")
    t0 = time.perf_counter()
    p = subprocess.run([sys.executable, "run_release.py"], cwd=variant, env=env,
                       text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    if p.returncode != 0:
        print(p.stdout)
        raise SystemExit(f"{name} release gate failed with exit code {p.returncode}")
    line = next((ln for ln in reversed(p.stdout.splitlines()) if ln.strip().startswith("{")), None)
    if not line:
        raise SystemExit(f"{name} release gate produced no JSON result")
    result = json.loads(line)
    if result.get("ReleasePASS") is not True:
        raise SystemExit(f"{name} ReleasePASS is not true")
    if result.get("ReleaseID") != EXPECTED[name]:
        raise SystemExit(f"{name} ReleaseID mismatch: {result.get('ReleaseID')}")
    oracle_results = result.get("OracleResults", [])
    caps = result.get("Capabilities", [])
    if len(oracle_results) != 30 or not all(x.get("pass") for x in oracle_results):
        raise SystemExit(f"{name} oracle conformance mismatch")
    if len(caps) != 14:
        raise SystemExit(f"{name} capability count mismatch")
    print(f"ReleaseID={result['ReleaseID']}")
    print(f"oracles={len(oracle_results)}/30 PASS; capabilities={len(caps)}/14")
    print(f"[{name} release gate] PASS ({time.perf_counter()-t0:.3f}s)")

def run(label: str, args: list[str]) -> None:
    print(f"\n=== {label} ===")
    t0 = time.perf_counter()
    p = subprocess.run([sys.executable, *args], cwd=ROOT, text=True)
    if p.returncode != 0:
        raise SystemExit(f"{label} failed with exit code {p.returncode}")
    print(f"[{label}] PASS ({time.perf_counter()-t0:.3f}s)")

def main() -> int:
    run_release("baseline")
    run_release("agenda")
    run("peripheral symbolic heat bridge", ["external_symbolic_heat_bridge/run_symbolic_heat_bridge.py", "--output", "data/heat_symbolic_bridge_result.json"])
    run("deterministic differential equivalence", ["random_support_differential.py"])
    run("paper table regeneration", ["reproduce_paper_tables.py"])
    summary = ROOT / "generated" / "PAPER_RESULT_SUMMARY.json"
    data = json.loads(summary.read_text())
    print("\n=== paper-result summary ===")
    for k in sorted(data):
        print(f"{k}={data[k]}")
    print("\nREPRODUCE_ALL=PASS")
    print("Long performance reruns are intentionally separate; see README.md.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
