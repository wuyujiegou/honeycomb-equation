from __future__ import annotations
import importlib.util, json, statistics, time, platform, sys, types
from pathlib import Path
ROOT=Path(__file__).resolve().parent
BASE_PKG=ROOT/'variants/baseline/src/honeycomb_v0'
AGEN_PKG=ROOT/'variants/agenda/src/honeycomb_v0'

def load_pkg(alias, root):
    pkg=types.ModuleType(alias); pkg.__path__=[str(root)]; pkg.__package__=alias; sys.modules[alias]=pkg
    for mod in ('canonical','kernel'):
        name=f'{alias}.{mod}'; spec=importlib.util.spec_from_file_location(name,root/f'{mod}.py')
        m=importlib.util.module_from_spec(spec); sys.modules[name]=m; spec.loader.exec_module(m)
    return sys.modules[f'{alias}.kernel']
B=load_pkg('honeycomb_base_bench',BASE_PKG); A=load_pkg('honeycomb_agenda_bench',AGEN_PKG)

def chain(mod,n):
    roots={'p0'}; rules=[mod.SupportRule(frozenset({f'p{i}'}), f'p{i+1}') for i in range(n)]
    return roots,rules

def fanout(mod,n):
    roots={'r'}; rules=[mod.SupportRule(frozenset({'r'}), f'p{i}') for i in range(n)]
    return roots,rules

def wide(mod,n):
    roots={f'p{i}' for i in range(n)}; rules=[mod.SupportRule(frozenset(roots),'z')]
    return roots,rules

def run(mod,case,n,reps=31,warm=3):
    roots,rules={'chain':chain,'fanout':fanout,'wide':wide}[case](mod,n)
    k=mod.SupportKernel(); expected=None
    for _ in range(warm): expected=k.closure(roots,rules)
    vals=[]
    for _ in range(reps):
        t=time.perf_counter(); out=k.closure(roots,rules); vals.append(time.perf_counter()-t)
        if out != expected: raise RuntimeError('unstable closure')
    vals_sorted=sorted(vals)
    q1=statistics.median(vals_sorted[:len(vals_sorted)//2])
    q3=statistics.median(vals_sorted[len(vals_sorted)//2+1:])
    return {'n':n,'reps':reps,'median_s':statistics.median(vals),'q1_s':q1,'q3_s':q3,'iqr_s':q3-q1,'min_s':min(vals),'max_s':max(vals),'raw_s':vals}

cases=[('chain',500),('chain',1000),('chain',2000),('fanout',2000),('wide',5000)]
out={'environment':{'python':sys.version,'platform':platform.platform()},'cases':[]}
for case,n in cases:
    b=run(B,case,n); a=run(A,case,n)
    out['cases'].append({'case':case,'n':n,'baseline':b,'agenda':a,'speedup_median':b['median_s']/a['median_s']})
    print(case,n,'base',b['median_s'],b['q1_s'],b['q3_s'],'agenda',a['median_s'],a['q1_s'],a['q3_s'],'x',b['median_s']/a['median_s'])
p=ROOT/'data/benchmark_variability_31.json'; p.write_text(json.dumps(out,indent=2))
print('wrote',p)
