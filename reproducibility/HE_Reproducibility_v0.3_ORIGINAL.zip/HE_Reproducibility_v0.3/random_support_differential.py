from __future__ import annotations
import json, random, sys, types, importlib.util, time
from pathlib import Path

ROOT=Path(__file__).resolve().parent
BASE_PKG=ROOT/'variants/baseline/src/honeycomb_v0'
AGEN_PKG=ROOT/'variants/agenda/src/honeycomb_v0'
OUT=ROOT/'data/random_equivalence_v2.json'
CONFIG={
  'seeds':'0..999',
  'proposition_count':[8,40],
  'root_count':[1,5],
  'rule_count':[8,80],
  'premises_per_rule':[1,4],
  'conflict_pair_count':[0,6],
  'sampling':'uniform integer counts; premise propositions sampled without replacement; cycles and self-dependencies allowed',
}

def load_pkg(alias, root):
    pkg=types.ModuleType(alias); pkg.__path__=[str(root)]; pkg.__package__=alias; sys.modules[alias]=pkg
    for mod in ('canonical','kernel'):
        name=f'{alias}.{mod}'; spec=importlib.util.spec_from_file_location(name,root/f'{mod}.py')
        m=importlib.util.module_from_spec(spec); sys.modules[name]=m; spec.loader.exec_module(m)
    return sys.modules[f'{alias}.kernel']
B=load_pkg('honeycomb_base',BASE_PKG); A=load_pkg('honeycomb_agenda',AGEN_PKG)

def make(seed:int):
    rnd=random.Random(seed); n=rnd.randint(*CONFIG['proposition_count']); props=[f'p{i}' for i in range(n)]
    nr=min(rnd.randint(*CONFIG['root_count']),n); roots=sorted(rnd.sample(props,nr)); rules=[]
    for _ in range(rnd.randint(*CONFIG['rule_count'])):
        k=min(rnd.randint(*CONFIG['premises_per_rule']),n)
        rules.append({'premises':sorted(rnd.sample(props,k)),'conclusion':rnd.choice(props)})
    pairs=[]; npairs=min(rnd.randint(*CONFIG['conflict_pair_count']),n//2)
    if npairs:
        chosen=rnd.sample(props,2*npairs)
        pairs=[sorted(chosen[i:i+2]) for i in range(0,len(chosen),2)]
    return roots,rules,pairs

def execute(mod, roots, rows, pairs):
    rules=[mod.SupportRule(frozenset(x['premises']),x['conclusion']) for x in rows]
    k=mod.SupportKernel()
    return k.closure(roots,rules), k.quarantine(roots,rules,[tuple(x) for x in pairs])

started=time.perf_counter(); mismatch=None
for seed in range(1000):
    roots,rows,pairs=make(seed); bc,bq=execute(B,roots,rows,pairs); ac,aq=execute(A,roots,rows,pairs)
    if bc!=ac or bq!=aq:
        mismatch={'seed':seed,'closure_equal':bc==ac,'quarantine_equal':bq==aq,'roots':roots,'rules':rows,'conflicts':pairs,
                  'baseline_closure':sorted(bc),'agenda_closure':sorted(ac),'baseline_quarantine':sorted(bq),'agenda_quarantine':sorted(aq)}
        break
res={'generator':CONFIG,'random_seeds':1000,'comparisons':2000 if mismatch is None else 2*(mismatch['seed']+1),
     'closure_equivalent':mismatch is None or mismatch['closure_equal'],
     'quarantine_equivalent':mismatch is None or mismatch['quarantine_equal'],
     'mismatch_count':0 if mismatch is None else 1,'first_mismatch':mismatch,'elapsed_s':time.perf_counter()-started}
OUT.write_text(json.dumps(res,indent=2,sort_keys=True)); print(json.dumps(res,indent=2,sort_keys=True))
if mismatch: raise SystemExit(1)
