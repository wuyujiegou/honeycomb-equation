from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import sys

import sympy as sp

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
BASELINE = ROOT / "variants" / "baseline"
sys.path.insert(0, str(BASELINE / "src"))

from honeycomb_v0 import (  # noqa: E402
    CertifiedRoot,
    DSLCompiler,
    PDEBinder,
    RuntimeTrustPolicy,
    SupportKernel,
    TheoremFixtureRegistry,
    DeclarativeAutoEvidenceRouter,
    canonical_data,
    content_id,
    file_sha256,
)

EXPECTED_RELEASE_ID = "51db4cc3854e6a50395b33f71109a54f0dc84c3a1aae2d89cc8a6448fa12cde1"
ISSUER_ID = "peripheral-sympy-heat-checker"
SOLUTION_CLAIM = "SYMBOLIC_PDE_SOLUTION_CHECK"
AGREEMENT_CLAIM = "ANALYTIC_QUERY_AGREEMENT"


def load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def sha256_json(obj: object) -> str:
    payload = json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def parse_expr(text: str, x, y, t):
    allowed = {
        "x": x,
        "y": y,
        "t": t,
        "pi": sp.pi,
        "exp": sp.exp,
        "cos": sp.cos,
        "sin": sp.sin,
    }
    return sp.sympify(text, locals=allowed)


def is_zero(expr) -> bool:
    return sp.simplify(sp.expand_trig(expr)) == 0


def check_fixture(path: Path) -> dict:
    raw = load_json(path)
    x, y, t = sp.symbols("x y t", real=True)
    u = parse_expr(raw["solution"], x, y, t)
    u0 = parse_expr(raw["initial"], x, y, t)
    kappa = sp.Rational(raw["kappa"])
    source = parse_expr(raw["source"], x, y, t)

    lap = sp.diff(u, x, 2) + sp.diff(u, y, 2)
    pde = sp.simplify(sp.diff(u, t) - kappa * lap - source)
    initial = sp.simplify(u.subs(t, 0) - u0)
    bx0 = sp.simplify(sp.diff(u, x).subs(x, 0))
    bxpi = sp.simplify(sp.diff(u, x).subs(x, sp.pi))
    by0 = sp.simplify(sp.diff(u, y).subs(y, 0))
    bypi = sp.simplify(sp.diff(u, y).subs(y, sp.pi))
    mean = sp.simplify(sp.integrate(sp.integrate(u, (x, 0, sp.pi)), (y, 0, sp.pi)) / sp.pi**2)
    mean_rate = sp.simplify(sp.diff(mean, t))

    residuals = {
        "pde": str(pde),
        "initial": str(initial),
        "neumann_x0": str(bx0),
        "neumann_xpi": str(bxpi),
        "neumann_y0": str(by0),
        "neumann_ypi": str(bypi),
    }
    valid = all(is_zero(v) for v in (pde, initial, bx0, bxpi, by0, bypi))
    return {
        "case_id": raw["case_id"],
        "fixture_sha256": file_sha256(path),
        "solution": str(u),
        "pde_residual": str(pde),
        "boundary_initial_residuals": residuals,
        "spatial_mean": str(mean),
        "spatial_mean_rate": str(mean_rate),
        "valid": valid,
    }


def run_he_baseline() -> dict:
    baseline_release = load_json(ROOT / "data" / "baseline_release.json")
    if baseline_release.get("ReleaseID") != EXPECTED_RELEASE_ID:
        raise RuntimeError("pinned baseline ReleaseID mismatch")

    compiler = DSLCompiler()
    model_raw = load_json(BASELINE / "examples" / "heat_neumann.model.json")
    query_raw = load_json(BASELINE / "examples" / "heat_mean.query.json")
    profile = compiler.compile_model(model_raw)
    bound = PDEBinder().bind(profile)
    query = compiler.compile_query(query_raw, profile)
    registry = TheoremFixtureRegistry.from_path(BASELINE / "theorems" / "theorem_fixtures.json")
    result = DeclarativeAutoEvidenceRouter().adapt(bound, query, registry, release_id=EXPECTED_RELEASE_ID)
    if result.status != "VALID" or result.output is None or result.report is None:
        raise RuntimeError(f"frozen HE baseline heat run failed: {result.status}: {result.reason}")
    return {
        "release_id": EXPECTED_RELEASE_ID,
        "model_id": result.model_id,
        "query_id": result.query_id,
        "status": result.status,
        "output_kind": result.output.kind,
        "output_value": canonical_data(result.output.value),
        "report_status": result.report.status,
        "faces": canonical_data(result.faces),
        "active_support_count": len(result.active),
    }


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Exact symbolic heat checker + frozen HE query-agreement bridge")
    ap.add_argument("--output", type=Path, default=None)
    ns = ap.parse_args(argv)

    good = check_fixture(HERE / "fixtures" / "heat_good.json")
    bad = check_fixture(HERE / "fixtures" / "heat_bad.json")
    he = run_he_baseline()

    checker_cid = file_sha256(Path(__file__).resolve())
    good_solution_prop = content_id({
        "type": "PeripheralSymbolicHeatSolutionCheck",
        "checker_content_id": checker_cid,
        "fixture_sha256": good["fixture_sha256"],
        "pde_residual": good["pde_residual"],
        "valid": good["valid"],
    })

    good_agrees = (
        good["valid"]
        and good["spatial_mean_rate"] == "0"
        and he["output_kind"] == "EXACT_LAW"
        and he["report_status"] == "CURRENT"
        and he["output_value"].get("derivative") == "measure(Omega)*d_dt(mean(u))"
        and he["output_value"].get("retained_terms") == [{"object": "<f,1>", "sign": -1}]
    )
    agreement_prop = content_id({
        "type": "AnalyticQueryAgreement",
        "checker_content_id": checker_cid,
        "good_fixture_sha256": good["fixture_sha256"],
        "he_release_id": he["release_id"],
        "he_query_id": he["query_id"],
        "analytic_mean_rate": good["spatial_mean_rate"],
        "he_source_specialization": "f=0",
        "agreement": good_agrees,
    })

    roots = []
    allowed = set()
    if good["valid"]:
        roots.append(CertifiedRoot(good_solution_prop, ISSUER_ID, checker_cid, SOLUTION_CLAIM, True))
        allowed.add((ISSUER_ID, checker_cid, SOLUTION_CLAIM))
    if good_agrees:
        roots.append(CertifiedRoot(agreement_prop, ISSUER_ID, checker_cid, AGREEMENT_CLAIM, True))
        allowed.add((ISSUER_ID, checker_cid, AGREEMENT_CLAIM))

    policy = RuntimeTrustPolicy("peripheral-symbolic-heat-policy-v1", frozenset(allowed))
    trusted = SupportKernel().certified_closure(tuple(roots), tuple(), policy)

    bad_query_coincidence = (bad["spatial_mean"] == "2" and bad["spatial_mean_rate"] == "0")
    bad_root_minted = bool(bad["valid"])

    result = {
        "experiment": "HE_PERIPHERAL_SYMBOLIC_HEAT_BRIDGE_V1",
        "status": "CLOSED" if good_agrees and agreement_prop in trusted and not bad_root_minted else "FAILED",
        "scope": "peripheral exact symbolic checker bridge; not independent validated-numerics replay",
        "checker": {
            "backend": "SymPy",
            "version": sp.__version__,
            "checker_content_id": checker_cid,
            "exact_arithmetic": True,
        },
        "frozen_he": he,
        "good_case": good,
        "bad_case": {
            **bad,
            "query_value_coincides_with_expected_mean": bad_query_coincidence,
            "trusted_root_minted": bad_root_minted,
            "rejection_stage": "PDE_RESIDUAL" if not bad["valid"] else None,
        },
        "trust_bridge": {
            "issuer_id": ISSUER_ID,
            "solution_claim_class": SOLUTION_CLAIM,
            "agreement_claim_class": AGREEMENT_CLAIM,
            "good_solution_root": good_solution_prop if good["valid"] else None,
            "analytic_query_agreement_root": agreement_prop if good_agrees else None,
            "trusted_root_count": len(trusted),
            "analytic_query_agreement": bool(good_agrees and agreement_prop in trusted),
        },
        "classification": {
            "peripheral_symbolic_checker_bridge": "CLOSED",
            "status_label_semantics": "experimental/replay status only; CLOSED is not an HE query-output class",
            "analytic_query_agreement": "TRUE" if good_agrees else "FALSE",
            "actual_independent_external_rigorous_pde_replay": "OPEN",
            "he_core_release_modified": False,
        },
    }
    result["result_sha256"] = sha256_json(result)

    text = json.dumps(result, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
    if ns.output:
        out = ns.output if ns.output.is_absolute() else ROOT / ns.output
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(text, encoding="utf-8")
    print(text, end="")
    return 0 if result["status"] == "CLOSED" else 1


if __name__ == "__main__":
    raise SystemExit(main())
