# Peripheral exact symbolic checker bridge for the HE heat regression

This experiment is deliberately **outside** the frozen HE baseline source tree. It checks one exact
analytic solution of the heat equation and then compares the checked query image with the frozen HE
mean-law output. It does not modify the baseline ReleaseID and it does not claim replay of an
independent validated-numerics PDE backend.

The frozen model is

\[
 u_t-\tfrac12\Delta u=0\quad\text{on }(0,\pi)^2,
 \qquad \partial_nu=0,
 \qquad u(0,x,y)=2+\cos x.
\]

The positive fixture is `u=2+exp(-t/2)*cos(x)`. The negative fixture replaces `1/2` by `1/3` in the
decay exponent. Both candidates have spatial mean 2, so the negative fixture is intentionally useful:
query agreement alone cannot establish PDE validity. The bad candidate must first fail the PDE
residual check and receives no trusted checker root.

## Run

From the reproducibility-package root:

```bash
python -m pip install -r external_symbolic_heat_bridge/requirements-symbolic.txt
python external_symbolic_heat_bridge/run_symbolic_heat_bridge.py \
  --output data/heat_symbolic_bridge_result.json
```

Expected high-level result:

- good PDE/boundary/initial residuals: exact zero;
- good spatial mean: exactly 2; mean rate: exactly 0;
- bad PDE residual: `exp(-t/3)*cos(x)/6`, hence rejected;
- frozen HE baseline returns `EXACT_LAW` for the mean query;
- `ANALYTIC_QUERY_AGREEMENT = TRUE` only on the accepted good-case bridge;
- peripheral symbolic-checker bridge: `CLOSED`;
- independent external rigorous PDE replay: `OPEN`.

The symbolic checker uses SymPy exact expressions and rational coefficients. The HE trust ingress in
this experiment uses the frozen baseline `TrustGate` and `SupportKernel` APIs, but the checker itself is
not part of the HE Core or the 51db baseline. It is a separately reproducible evidence producer that
instantiates the same checked-ingress interface intended for future validated-numerics or proof backends,
and therefore does not alter the baseline ReleaseID. `CLOSED` above is an experimental-status label for
this bridge, not an HE query-output classification.
