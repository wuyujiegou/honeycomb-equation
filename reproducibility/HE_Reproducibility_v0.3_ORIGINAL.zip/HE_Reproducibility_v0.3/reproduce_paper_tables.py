from __future__ import annotations
from pathlib import Path
import json, re, csv

ROOT=Path(__file__).resolve().parent
DATA=ROOT/'data'; OUT=ROOT/'generated'; OUT.mkdir(exist_ok=True)

def load(name): return json.loads((DATA/name).read_text())

def write(name,s): (OUT/name).write_text(s.rstrip()+"\n")

base=load('baseline_release.json')
agenda=load('agenda_release.json')
comp=load('benchmark_comparison.json')
rand=load('random_equivalence_v2.json')
e4=load('E4_REPLAY_STATUS.json')
heat_bridge=load('heat_symbolic_bridge_result.json')
entry=load('entrypoint_benchmark.json')

# Table 1: release conformance
rows=[
('Baseline ReleaseID',base['ReleaseID']),('Baseline tests','92/92 PASS'),('Pinned oracles',f"{len(base['OracleResults'])}/{len(base['OracleResults'])} PASS"),
('Capabilities',f"{len(base['Capabilities'])}/{len(base['Capabilities'])} present"),('Closed-loop oracle',str(next(x['pass'] for x in base['OracleResults'] if x['id']=='gg.he.closed.loop'))),
('Agenda ReleaseID',agenda['ReleaseID']),('KsafeID preserved',str(base['KsafeID']==agenda['KsafeID'])),('OutputID preserved',str(base['OutputID']==agenda['OutputID'])),
('FaceVector preserved',str(base['FaceVector']==agenda['FaceVector'])),('OracleResults preserved',str(base['OracleResults']==agenda['OracleResults']))]
write('TABLE_release_conformance.md','| Measure | Result |\n|---|---|\n'+'\n'.join(f'| {a} | `{b}` |' for a,b in rows))

# Table 2: performance, pure closure only
pure=[r for r in comp['rows'] if r['mode']=='closure']
pure=sorted(pure,key=lambda r:(r['shape'],r['rules']))
lines=['| Shape | Rules | Baseline median (s) | Agenda median (s) | Speedup |','|---|---:|---:|---:|---:|']
for r in pure:
    lines.append(f"| {r['shape']} | {r['rules']} | {r['baseline_median_s']:.6f} | {r['agenda_median_s']:.6f} | {r['speedup']:.2f}x |")
write('TABLE_support_performance.md','\n'.join(lines))
with (OUT/'TABLE_support_performance.csv').open('w',newline='') as f:
    w=csv.writer(f); w.writerow(['shape','rules','baseline_median_s','agenda_median_s','speedup'])
    for r in pure: w.writerow([r['shape'],r['rules'],r['baseline_median_s'],r['agenda_median_s'],r['speedup']])

# Table 3: entry point times
lines=['| Entry point | Median (s) | Min (s) | Max (s) | Exit codes |','|---|---:|---:|---:|---|']
for r in entry['rows']:
    lines.append(f"| {r['case']} | {r['median_s']:.6f} | {r['min_s']:.6f} | {r['max_s']:.6f} | {','.join(map(str,r['exit_codes']))} |")
write('TABLE_entrypoint_latency.md','\n'.join(lines))

# Table 4: semantic differential test
write('TABLE_differential_equivalence.md',f'''| Measure | Result |\n|---|---|\n| Random seeds | {rand['random_seeds']} |\n| Closure + quarantine comparisons | {rand['comparisons']} |\n| Closure equivalent | {rand['closure_equivalent']} |\n| Quarantine equivalent | {rand['quarantine_equivalent']} |\n| Elapsed | {rand['elapsed_s']:.3f} s |''')

# Table 5: E4 status
lines=['| Gate | Status | Blocker |','|---|---|---|']
for key in ('E4a','E4b','E4c'):
    row=e4[key]; lines.append(f"| {key} | `{row['status']}` | {row['blocker']} |")
lines.append(f"| peripheral symbolic heat bridge | `{e4['peripheral_symbolic_checker_bridge']['status']}` | local exact checker; not independent external replay |")
lines.append(f"| generic ingress | `{e4['ingress_contract']['status']}` | actual external PDE replay: `{e4['ingress_contract']['actual_external_pde_replay']}` |")
write('TABLE_external_replay_status.md','\n'.join(lines))

# Symbolic heat bridge detail
hb=heat_bridge
lines=['| Check | Result |','|---|---|']
lines.append(f"| Good PDE residual | `{hb['good_case']['pde_residual']}` |")
lines.append(f"| Good boundary/initial residuals | `all zero = {hb['good_case']['valid']}` |")
lines.append(f"| Good mean / mean rate | `{hb['good_case']['spatial_mean']}` / `{hb['good_case']['spatial_mean_rate']}` |")
lines.append(f"| Bad PDE residual | `{hb['bad_case']['pde_residual']}` |")
lines.append(f"| Bad root minted | `{hb['bad_case']['trusted_root_minted']}` |")
lines.append(f"| Frozen HE output | `{hb['frozen_he']['output_kind']}` / report `{hb['frozen_he']['report_status']}` |")
lines.append(f"| ANALYTIC_QUERY_AGREEMENT | `{hb['classification']['analytic_query_agreement']}` |")
lines.append(f"| Peripheral bridge | `{hb['classification']['peripheral_symbolic_checker_bridge']}` |")
lines.append(f"| Status-label semantics | {hb['classification']['status_label_semantics']} |")
lines.append(f"| Independent external rigorous replay | `{hb['classification']['actual_independent_external_rigorous_pde_replay']}` |")
write('TABLE_symbolic_heat_bridge.md','\n'.join(lines))

# Resource logs
resource_dir=ROOT/'resource_logs'
lines=['| Command | Wall time | Max RSS (KiB) |','|---|---:|---:|']
for stem,label in [('run_release','run_release.py'),('he_selfcheck','he-selfcheck'),('pytest','pytest -q')]:
    txt=(resource_dir/f'{stem}.time.txt').read_text()
    wall=re.search(r'Elapsed \(wall clock\) time \(h:mm:ss or m:ss\):\s*(\S+)',txt).group(1)
    rss=re.search(r'Maximum resident set size \(kbytes\):\s*(\d+)',txt).group(1)
    lines.append(f'| {label} | {wall} | {rss} |')
write('TABLE_resource_use.md','\n'.join(lines))


# Table 6: extended support stress / allocation tradeoff
stress_b=load('stress_baseline.json')
stress_a=load('stress_agenda.json')
lines=['| Case | Rules | Premise edges | Equivalent | Baseline (s) | Agenda (s) | Speedup | Baseline peak alloc (MiB) | Agenda peak alloc (MiB) |',
       '|---|---:|---:|---|---:|---:|---:|---:|---:|']
for b,a in zip(stress_b['rows'],stress_a['rows']):
    assert (b['kind'],b['n'],b['width'])==(a['kind'],a['n'],a['width'])
    equiv=b['result_sha256']==a['result_sha256']
    speed=b['median_s']/a['median_s']
    lines.append(f"| {b['kind']} n={b['n']} w={b['width']} | {b['rules']} | {b['premise_edges']} | {equiv} | {b['median_s']:.6f} | {a['median_s']:.6f} | {speed:.2f}x | {b['peak_python_alloc_bytes']/1048576:.2f} | {a['peak_python_alloc_bytes']/1048576:.2f} |")
write('TABLE_support_stress.md','\n'.join(lines))



# Table 8: oracle-family coverage
from collections import Counter
def fam(oid):
    if oid.startswith(('ga.','gb.','gc.','gd.','ge.','gf.','gg.')): return 'ga--gg guards'
    if oid.startswith('r1.'): return 'r1 PDE ingress/binding'
    if oid.startswith('r2.'): return 'r2 composition'
    if oid.startswith(('r3.','r4.','r5.')): return 'r3--r5 query semantics'
    if oid.startswith('r6.'): return 'r6 infinite/weak semantics'
    if oid.startswith('r7.'): return 'r7 output scope'
    if oid.startswith('r8.'): return 'r8 lineage'
    return 'other'
c=Counter(fam(x['id']) for x in base['OracleResults'])
lines=['| Oracle family | Count |','|---|---:|']
for k in ['ga--gg guards','r1 PDE ingress/binding','r2 composition','r3--r5 query semantics','r6 infinite/weak semantics','r7 output scope','r8 lineage']:
    lines.append(f'| {k} | {c[k]} |')
write('TABLE_oracle_families.md','\n'.join(lines))

# Table 7: 31-run variability for principal support workloads
var=load('benchmark_variability_31.json')
lines=['| Workload | Baseline median [IQR] (s) | Agenda median [IQR] (s) | Speedup |',
       '|---|---:|---:|---:|']
for r in var['cases']:
    b=r['baseline']; a=r['agenda']; label=f"{r['case']} n={r['n']}"
    lines.append(f"| {label} | {b['median_s']:.6f} [{b['q1_s']:.6f}, {b['q3_s']:.6f}] | {a['median_s']:.6f} [{a['q1_s']:.6f}, {a['q3_s']:.6f}] | {r['speedup_median']:.2f}x |")
write('TABLE_support_variability_31.md','\n'.join(lines))

summary={
 'baseline_release_id':base['ReleaseID'], 'agenda_release_id':agenda['ReleaseID'],
 'oracle_count':len(base['OracleResults']), 'capability_count':len(base['Capabilities']),
 'random_comparisons':rand['comparisons'], 'principal_chain_speedup_31run':max(r['speedup_median'] for r in var['cases'] if r['case']=='chain'),
 'actual_external_replay':e4['ingress_contract']['actual_external_pde_replay'],
 'peripheral_symbolic_heat_bridge':heat_bridge['classification']['peripheral_symbolic_checker_bridge'],
 'analytic_query_agreement':heat_bridge['classification']['analytic_query_agreement']
}
write('PAPER_RESULT_SUMMARY.json',json.dumps(summary,indent=2,sort_keys=True))
print(json.dumps(summary,sort_keys=True))
