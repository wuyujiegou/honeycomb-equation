| Oracle family | Count |
|---|---:|
| ga--gg guards | 8 |
| r1 PDE ingress/binding | 7 |
| r2 composition | 4 |
| r3--r5 query semantics | 3 |
| r6 infinite/weak semantics | 6 |
| r7 output scope | 1 |
| r8 lineage | 1 |
