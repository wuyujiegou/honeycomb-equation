| Gate | Status | Blocker |
|---|---|---|
| E4a | `PUBLICATION_BACKED_REPLAY_OPEN` | source artifact availability |
| E4b | `CODE_AVAILABLE_RIGOROUS_RUNTIME_BLOCKED` | MATLAB+INTLAB unavailable |
| E4c | `OPEN_SOURCE_CANDIDATE_RUNTIME_BLOCKED` | Julia unavailable; dependencies not runtime-pinned |
| peripheral symbolic heat bridge | `CLOSED` | local exact checker; not independent external replay |
| generic ingress | `PASS_ADAPTER_MECHANICS` | actual external PDE replay: `OPEN` |
