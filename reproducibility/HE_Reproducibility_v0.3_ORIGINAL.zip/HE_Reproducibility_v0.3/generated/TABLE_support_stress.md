| Case | Rules | Premise edges | Equivalent | Baseline (s) | Agenda (s) | Speedup | Baseline peak alloc (MiB) | Agenda peak alloc (MiB) |
|---|---:|---:|---|---:|---:|---:|---:|---:|
| wide n=100 w=0 | 1 | 100 | True | 0.000187 | 0.000194 | 0.96x | 0.02 | 0.02 |
| wide n=1000 w=0 | 1 | 1000 | True | 0.001504 | 0.001916 | 0.79x | 0.14 | 0.18 |
| wide n=5000 w=0 | 1 | 5000 | True | 0.007944 | 0.010144 | 0.78x | 1.13 | 1.06 |
| chain_wide n=100 w=10 | 100 | 1000 | True | 0.003068 | 0.002557 | 1.20x | 0.02 | 0.04 |
| chain_wide n=500 w=10 | 500 | 5000 | True | 0.029450 | 0.012610 | 2.34x | 0.06 | 0.16 |
| chain_wide n=1000 w=10 | 1000 | 10000 | True | 0.099018 | 0.025581 | 3.87x | 0.12 | 0.30 |
| conflict_heavy n=500 w=0 | 1000 | 1000 | True | 0.022530 | 0.022140 | 1.02x | 0.22 | 0.25 |
| conflict_heavy n=2000 w=0 | 4000 | 4000 | True | 0.092622 | 0.093783 | 0.99x | 0.87 | 0.99 |
| conflict_heavy n=5000 w=0 | 10000 | 10000 | True | 0.230399 | 0.243177 | 0.95x | 2.73 | 3.23 |
