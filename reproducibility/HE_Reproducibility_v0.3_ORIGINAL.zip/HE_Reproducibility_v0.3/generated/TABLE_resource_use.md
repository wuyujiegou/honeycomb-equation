| Command | Wall time | Max RSS (KiB) |
|---|---:|---:|
| run_release.py | 0:00.94 | 113932 |
| he-selfcheck | 0:00.35 | 24136 |
| pytest -q | 0:10.23 | 152664 |
