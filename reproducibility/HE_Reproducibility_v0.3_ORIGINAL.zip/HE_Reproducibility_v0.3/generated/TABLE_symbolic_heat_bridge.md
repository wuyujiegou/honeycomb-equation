| Check | Result |
|---|---|
| Good PDE residual | `0` |
| Good boundary/initial residuals | `all zero = True` |
| Good mean / mean rate | `2` / `0` |
| Bad PDE residual | `exp(-t/3)*cos(x)/6` |
| Bad root minted | `False` |
| Frozen HE output | `EXACT_LAW` / report `CURRENT` |
| ANALYTIC_QUERY_AGREEMENT | `TRUE` |
| Peripheral bridge | `CLOSED` |
| Status-label semantics | experimental/replay status only; CLOSED is not an HE query-output class |
| Independent external rigorous replay | `OPEN` |
