| Measure | Result |
|---|---|
| Random seeds | 1000 |
| Closure + quarantine comparisons | 2000 |
| Closure equivalent | True |
| Quarantine equivalent | True |
| Elapsed | 5.378 s |
