| Entry point | Median (s) | Min (s) | Max (s) | Exit codes |
|---|---:|---:|---:|---|
| run_release | 0.979442 | 0.918896 | 1.023460 | 0 |
| heat_neumann | 0.695224 | 0.644967 | 0.751008 | 0 |
| heat_open_law | 0.664249 | 0.625113 | 0.750074 | 0 |
| two_cell_exact | 0.669495 | 0.645233 | 0.754496 | 0 |
| weak_oscillation | 0.677558 | 0.661538 | 0.735995 | 0 |
| installed_he_selfcheck | 0.377476 | 0.364594 | 1.196916 | 0 |
