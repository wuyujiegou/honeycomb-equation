# HE Software Companion Reproducibility Supplement

This package is separate from the runtime software package. It contains the exact baseline and
experimental-agenda source fixtures, deterministic differential generator, raw result data, and
table-regeneration scripts used for the software-companion manuscript.

## Quick verification

From the extracted directory, install the one peripheral symbolic-checker dependency and run:

```bash
python -m pip install -r external_symbolic_heat_bridge/requirements-symbolic.txt
python reproduce_all.py
```

This reruns both pinned release gates, the peripheral exact symbolic heat-checker bridge, the deterministic differential-equivalence experiment, and the manuscript table regeneration.
A successful run ends with:

```text
REPRODUCE_ALL=PASS
```

The full performance studies are deliberately separate because they are longer-running and timing values are environment-sensitive:

```bash
python benchmark_variability.py
python stress_support_kernel.py
```

## Main experiment files

- `external_symbolic_heat_bridge/`: exact SymPy checker for one heat-equation solution, bad-solution rejection, TrustGate ingress, and analytic/HE query agreement.
- `random_support_differential.py`: deterministic seeds 0--999; compares baseline and agenda closure/quarantine results.
- `reproduce_paper_tables.py`: rebuilds manuscript result tables from the recorded and regenerated data.
- `benchmark_variability.py`: repeated timing study used for the median/IQR performance result.
- `stress_support_kernel.py`: wide-hyperedge and conflict-heavy stress cases.
- `variants/baseline/`: frozen baseline implementation, ReleaseID `51db4c...`.
- `variants/agenda/`: experimental agenda implementation, ReleaseID `08e146...`.
- `generated/`: tables and machine-readable paper-result summary.
- `data/`: release and benchmark evidence used by the table generator.

The two variants intentionally have distinct source ReleaseIDs. Matching semantic outputs are a
result of differential validation; the performance variant is **not** presented as a new mathematical
algorithm or as the canonical software release.

## External rigorous replay boundary

The peripheral heat symbolic-checker bridge is `CLOSED`: it verifies PDE, Neumann-boundary, and initial residuals exactly for a pinned analytic heat solution, rejects a wrong decay rate at the PDE residual, admits only the valid checker claims through the frozen HE `TrustGate`, and confirms `ANALYTIC_QUERY_AGREEMENT = TRUE` for the accepted solution. Here `CLOSED` is an experimental-status label for this bridge, not an HE query-output classification. The checker is not part of the HE Core; it is a separately reproducible evidence producer that exercises the checked-ingress interface without changing the 51db baseline.

Independent external rigorous PDE replay remains `OPEN`. The symbolic experiment is a local exact checker bridge, not replay of an independent validated-numerics backend, and this supplement does not transform repository availability or publication metadata into positive theorem-replay credit.

## Runtime note

The evaluated manuscript environment used CPython 3.13.5. Core release/differential scripts use the Python standard library plus bundled source fixtures; the peripheral symbolic heat experiment additionally pins SymPy 1.14.0. Timing values are environment-specific; the semantic-equality
checks are the primary portable result.

## License

Copyright (c) 2026 Zhang Bingchao. This reproducibility supplement is released under the **MIT
License**; see `LICENSE`. The license covers the author-created scripts, recorded result data, and
bundled HE baseline/agenda source fixtures. No third-party source code is vendored in this package.
The software and scripts are provided "AS IS", without warranty.
