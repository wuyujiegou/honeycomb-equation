import argparse, json, statistics, time, platform, sys
from pathlib import Path

def load_variant(label):
    root=Path(__file__).resolve().parent/'variants'/label/'src'
    sys.path.insert(0,str(root))
    from honeycomb_v0.kernel import SupportRule, SupportKernel
    return SupportRule, SupportKernel

def chain(n):
    roots={'p0'}; rules=[SupportRule(frozenset({f'p{i}'}), f'p{i+1}') for i in range(n)]; return roots,rules

def fanout(n):
    roots={'r'}; rules=[SupportRule(frozenset({'r'}), f'p{i}') for i in range(n)]; return roots,rules

def wide(n):
    roots={f'p{i}' for i in range(n)}; rules=[SupportRule(frozenset(roots),'z')]; return roots,rules

def quartiles(vals):
    s=sorted(vals); n=len(s); med=statistics.median(s); lo=s[:n//2]; hi=s[n//2+1:] if n%2 else s[n//2:]
    return med, statistics.median(lo), statistics.median(hi)

def run(case,n,reps=31,warm=3):
    roots,rules={'chain':chain,'fanout':fanout,'wide':wide}[case](n); k=SupportKernel(); expected=None
    for _ in range(warm): expected=k.closure(roots,rules)
    vals=[]
    for _ in range(reps):
        t=time.perf_counter(); out=k.closure(roots,rules); vals.append(time.perf_counter()-t)
        if out != expected: raise RuntimeError('unstable closure')
    med,q1,q3=quartiles(vals)
    return {'case':case,'n':n,'reps':reps,'median_s':med,'q1_s':q1,'q3_s':q3,'iqr_s':q3-q1,'min_s':min(vals),'max_s':max(vals),'raw_s':vals}

if __name__=='__main__':
    ap=argparse.ArgumentParser(); ap.add_argument('--variant',choices=['baseline','agenda'],required=True); a=ap.parse_args()
    SupportRule,SupportKernel=load_variant(a.variant)
    cases=[('chain',500),('chain',1000),('chain',2000),('fanout',2000),('wide',5000)]
    out={'variant':a.variant,'environment':{'python':sys.version,'platform':platform.platform()},'cases':[run(c,n) for c,n in cases]}
    print(json.dumps(out))
