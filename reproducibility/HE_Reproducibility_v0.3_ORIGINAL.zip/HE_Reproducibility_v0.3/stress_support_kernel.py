from __future__ import annotations
import argparse, hashlib, json, statistics, time, tracemalloc, sys
from pathlib import Path

def load_variant(label):
    root=Path(__file__).resolve().parent/'variants'/label/'src'
    sys.path.insert(0,str(root))
    from honeycomb_v0.kernel import SupportKernel, SupportRule
    return SupportKernel, SupportRule


def digest(K):
    return hashlib.sha256(('\n'.join(sorted(K))).encode()).hexdigest()

def wide(n, SupportRule):
    roots=frozenset(f'p{i}' for i in range(n))
    rules=(SupportRule(roots,'goal'),)
    return roots,rules,()

def chain_wide(depth,width, SupportRule):
    shared=frozenset(f's{j}' for j in range(max(0,width-1)))
    roots=frozenset(set(shared)|{'r0'})
    rules=[]
    for i in range(1,depth+1):
        rules.append(SupportRule(frozenset(set(shared)|{f'r{i-1}'}),f'r{i}'))
    return roots,tuple(rules),()

def conflict_heavy(n, SupportRule):
    roots=frozenset({'seed'})
    rules=[]; conflicts=[]
    for i in range(n):
        a=f'a{i}'; b=f'b{i}'
        rules.append(SupportRule(frozenset({'seed'}),a))
        rules.append(SupportRule(frozenset({'seed'}),b))
        conflicts.append((a,b))
    return roots,tuple(rules),tuple(conflicts)

def run_case(kind,n,width,reps,SupportKernel,SupportRule):
    if kind=='wide': roots,rules,conf=wide(n,SupportRule); method='closure'
    elif kind=='chain_wide': roots,rules,conf=chain_wide(n,width,SupportRule); method='closure'
    else: roots,rules,conf=conflict_heavy(n,SupportRule); method='quarantine'
    k=SupportKernel()
    times=[]; out=None
    for _ in range(reps):
        t=time.perf_counter()
        out=k.quarantine(roots,rules,conf) if method=='quarantine' else k.closure(roots,rules)
        times.append(time.perf_counter()-t)
    tracemalloc.start()
    out2=k.quarantine(roots,rules,conf) if method=='quarantine' else k.closure(roots,rules)
    current,peak=tracemalloc.get_traced_memory(); tracemalloc.stop()
    assert out==out2
    return {
      'kind':kind,'n':n,'width':width,'rules':len(rules),'premise_edges':sum(len(r.premises) for r in rules),
      'method':method,'median_s':statistics.median(times),'min_s':min(times),'max_s':max(times),
      'peak_python_alloc_bytes':peak,'result_size':len(out),'result_sha256':digest(out)
    }

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--variant',choices=['baseline','agenda'],required=True); ap.add_argument('--label'); ap.add_argument('--out',required=True); ap.add_argument('--reps',type=int,default=5); a=ap.parse_args(); SupportKernel,SupportRule=load_variant(a.variant)
    cases=[]
    for n in (100,1000,5000): cases.append(('wide',n,0))
    for n in (100,500,1000): cases.append(('chain_wide',n,10))
    for n in (500,2000,5000): cases.append(('conflict_heavy',n,0))
    rows=[run_case(k,n,w,a.reps,SupportKernel,SupportRule) for k,n,w in cases]
    obj={'label':a.label or a.variant,'variant':a.variant,'repetitions':a.reps,'rows':rows}
    open(a.out,'w').write(json.dumps(obj,indent=2,sort_keys=True)+'\n')
    print(json.dumps(obj,sort_keys=True))
if __name__=='__main__': main()
